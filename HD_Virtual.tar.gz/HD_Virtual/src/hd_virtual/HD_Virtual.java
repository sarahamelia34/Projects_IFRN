/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hd_virtual;

/**
 *
 * @author Sarah
 */
public class HD_Virtual {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Grafico2 g = new Grafico2();
        g.setVisible(true);
        
        //Principal p = new Principal();
        //p.setVisible(true);
    }
    
}
