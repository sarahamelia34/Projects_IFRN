/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testecs;

/**
 *
 * @author Sarah Amelia
 */
public class RevisaoPOO {

    public static void main(String[] args) {
        Telefone meutim = new Telefone("preto", "Android");
        meutim.Ligar("9917-9087");
        meutim.Ligar("84", "9909-7688");
        meutim.Bemvindo();
        Telefone.Discar("Start");
    }

}

class Telefone {

    private String cor;
    private String Sis_Op;

    public Telefone(String cor, String Sis_Op) {//construtor
        this.cor = cor;
        this.Sis_Op = Sis_Op;
    }

    public void Ligar(String numero) {//metodo
        System.out.println("A cor é: " + cor + " e o SO é: " + Sis_Op);
        String texto = Bemvindo();

    }
    public void Ligar(String ddd, String numero){
        System.out.println("O DDD é: "+ddd+ " e o numero discado: "+numero);
        String texto = Bemvindo();
    }
    
    public String Bemvindo (){
        String texto = "Boa ligação";
        return texto; 
        
    }
    public static void Discar(String numero){
        System.out.println("Iniciando...");
    }

}
 