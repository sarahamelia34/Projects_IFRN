/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package testecs;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Sarah
 */
public class Servidor2 {
    public static void main(String[] args) throws IOException {
     ServerSocket servidor = new ServerSocket(12345); //declaração do socket na porta que está disponivel
     System.out.println("Porta 12345 aberta!");
     
     Socket cliente = servidor.accept();
     //espera por uma conexão e continua somente quando recebe uma.
     //retorna um socket para comunicar com o cliente que acaba de se conectar
     System.out.println("Nova conexão com o cliente " + cliente.getInetAddress().getHostAddress());
     Scanner s = new Scanner(cliente.getInputStream());
     while (s.hasNextLine()) {
         System.out.println(" Cliente escreveu: ");
         System.out.println(s.nextLine());
     }
     
     s.close();
     cliente.close();//Encerro o socket de comunicação
     servidor.close();//Encerro o ServerSocket   
        
    }
    
}
