/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package testecs;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;


/**
 *
 * @author Sarah
 */
public class Cliente2 {
    public static void main(String[] args) throws UnknownHostException, IOException {
     Scanner sc = new Scanner(System.in);
     Socket cliente = new Socket("127.0.0.1", 12345); //declaração socket teste cliente
     System.out.println("Nome do usuário: ");
     String nome = sc.nextLine();
     System.out.println(nome + " conectado ao servidor!");//stream da saída de dados
     System.out.println("Digite suas mensagens aqui: ");
     
     
     
     PrintStream saida = new PrintStream(cliente.getOutputStream());
     //criamos um objeto do tipo PrintStream para poder imprimir dados para o canal de saída do socket
     //converte os caracteres digitados para o formato adequado de envio através do socket
     
     while (sc.hasNextLine()) {
       saida.println(sc.nextLine());
     }
     
     saida.close();
     sc.close();
     cliente.close();
        
        
        
    }
    
}
