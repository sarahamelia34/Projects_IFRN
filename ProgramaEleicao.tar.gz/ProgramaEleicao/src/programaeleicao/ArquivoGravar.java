/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package programaeleicao;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author --Kennedi--
 */
public class ArquivoGravar {
    public static void main(String[] args){
        String arquivo = "C:\\Locadora\\dados_cliente.txt";
        try {
            FileWriter fw = new FileWriter(arquivo, true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.newLine();
            bw.write("Martina Diva!");
            bw.newLine();
            bw.write("Obrigado!");
            bw.close();
            fw.close();
        } catch (IOException ex) {
            Logger.getLogger(ArquivoGravar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
